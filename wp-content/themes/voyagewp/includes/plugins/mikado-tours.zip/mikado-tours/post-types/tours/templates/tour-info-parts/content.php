<?php
if(get_the_content() !== '') : ?>
    <div class="mkdf-info-section-part mkdf-tour-item-content">
        <?php the_content(); ?>
    </div>
<?php endif; ?>