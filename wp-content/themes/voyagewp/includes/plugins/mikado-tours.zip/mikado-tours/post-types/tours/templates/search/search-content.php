<div class="mkdf-tours-search-content">
		<div class="mkdf-grid-row">
			<?php echo mkdf_tours_get_search_page_items_loop_html($tours_list); ?>
		</div>
</div>