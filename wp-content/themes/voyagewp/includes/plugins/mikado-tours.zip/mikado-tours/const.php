<?php

define('MIKADOF_TOURS_VERSION', '1.0');
define('MIKADOF_TOURS_ABS_PATH', dirname(__FILE__));
define('MIKADOF_TOURS_REL_PATH', dirname(plugin_basename(__FILE__)));
define('MIKADOF_TOURS_CPT_PATH', MIKADOF_TOURS_ABS_PATH.'/post-types');